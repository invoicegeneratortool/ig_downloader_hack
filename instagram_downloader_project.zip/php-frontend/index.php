
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instagram Downloader</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .result, .error { margin-top: 20px; }
        .error { color: red; }
        .result ul { list-style-type: none; padding: 0; }
        .result ul li { margin: 5px 0; }
    </style>
</head>
<body>
    <h1>Instagram Downloader</h1>
    <form method="POST">
        <label for="instagramLink">Enter Instagram Link:</label>
        <input type="url" id="instagramLink" name="instagramLink" placeholder="Paste Instagram link here" required>
        <button type="submit">Download</button>
    </form>

    <div class="error">
        <?php if (isset($error)) echo $error; ?>
    </div>
    <div class="result">
        <?php if (isset($resultHtml)) echo $resultHtml; ?>
    </div>
</body>
</html>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $link = $_POST['instagramLink'];

    if (empty($link)) {
        $error = "Please enter a valid Instagram link!";
    } else {
        $backendUrl = 'http://localhost:3000/scrape'; // Adjust the Puppeteer server URL
        $payload = json_encode(['link' => $link]);

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $backendUrl);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Content-Length: ' . strlen($payload)
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode === 200) {
            $responseData = json_decode($response, true);
            if ($responseData['success']) {
                $downloadLinks = $responseData['downloadLinks'];
                if (count($downloadLinks) > 1) {
                    $resultHtml = "<p>Download Links:</p><ul>";
                    foreach ($downloadLinks as $link) {
                        $resultHtml .= "<li><a href='$link' target='_blank'>$link</a></li>";
                    }
                    $resultHtml .= "</ul>";
                } else {
                    $resultHtml = "<p>Download Link: <a href='" . $downloadLinks[0] . "' target='_blank'>" . $downloadLinks[0] . "</a></p>";
                }
            } else {
                $error = $responseData['message'] ?? 'An error occurred while processing the request.';
            }
        } else {
            $error = 'Failed to connect to the backend server.';
        }
    }
}
?>
