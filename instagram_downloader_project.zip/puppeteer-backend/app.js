
const express = require("express");
const puppeteer = require("puppeteer-extra");
const StealthPlugin = require("puppeteer-extra-plugin-stealth");

puppeteer.use(StealthPlugin());

const app = express();
app.use(express.json());

app.post("/scrape", async (req, res) => {
  const { link } = req.body;

  if (!link || !link.startsWith("https://www.instagram.com/")) {
    return res.status(400).json({ success: false, message: "Invalid Instagram link." });
  }

  try {
    const browser = await puppeteer.launch({
      headless: true,
      args: ["--no-sandbox", "--disable-setuid-sandbox"],
    });
    const page = await browser.newPage();

    await page.goto("https://snapinsta.app", { waitUntil: "domcontentloaded" });
    await page.waitForSelector("#url");

    // Input the Instagram link
    await page.type("#url", link);
    await page.click("#submit");
    await page.waitForSelector(".download-items", { timeout: 15000 });

    // Scrape download links
    const downloadLinks = await page.evaluate(() => {
      return Array.from(document.querySelectorAll(".download-items a"))
        .map((a) => a.href)
        .filter((href) => href.includes("http"));
    });

    await browser.close();

    res.json({ success: true, downloadLinks });
  } catch (error) {
    console.error("Error during scraping:", error);
    res.status(500).json({ success: false, message: "Failed to scrape data." });
  }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Puppeteer server running on http://localhost:${PORT}`);
});
